export interface StaffMember {
  id: string; // អត្តលេខមន្ត្រី (Civil Servant ID)
  name: string; // គោត្តនាមនិងនាម
  gender: 'ប្រុស' | 'ស្រី';
  position: string; // តួនាទី
  cls: string; // ថ្នាក់
  phone: string; // លេខទូរស័ព្ទ
  role: 'director' | 'vice_director' | 'admin' | 'teacher';
  staffType?: 'civil_servant' | 'contract'; // មន្ត្រីរាជការស៊ីវិល ឬ មន្ត្រីជាប់កិច្ចសន្យា
  dob?: string; // ថ្ងៃខែឆ្នាំកំណើត
}

export interface SignatureRecord {
  time: string; // HH:mm:ss
  sig: string; // base64 data URL
  lat?: number | null;
  lng?: number | null;
  dist?: number | null;
}

export interface AttendanceDayRecord {
  m_in?: SignatureRecord | null; // ព្រឹក ចូល
  m_out?: SignatureRecord | null; // ព្រឹក ចេញ
  a_in?: SignatureRecord | null; // ល្ងាច/រសៀល ចូល
  a_out?: SignatureRecord | null; // ល្ងាច/រសៀល ចេញ
  phone?: string;
  late?: string; // មកយឺត (e.g. 15 នាទី, ឬ "យឺត")
  early?: string; // ចេញមុន (e.g. 20 នាទី, ឬ "ចេញមុន")
  permissionDoc?: string; // លិខិតបញ្ជាក់ (e.g. លិខិតច្បាប់, លិខិតបេសកកម្ម, លិខិតពេទ្យ)
  leaveType?: string; // ប្រភេទច្បាប់ឈប់សម្រាក (ប្រចាំឆ្នាំ, រយៈពេលខ្លី, មាតុភាព, ព្យាបាលជំងឺ, កិច្ចការផ្ទាល់ខ្លួន)
  measure?: string; // វិធានការ
  note?: string; // ផ្សេងៗ
}

export type DayAttendanceMap = Record<string, AttendanceDayRecord>;

export type GPSStatus = 'loading' | 'ok' | 'bad' | 'denied' | 'error' | 'simulated';

export interface GPSState {
  status: GPSStatus;
  lat: number | null;
  lng: number | null;
  distance: number | null;
  accuracy: number | null;
  isSimulated?: boolean;
}

export interface UserSession {
  name: string;
  phone: string;
  role: 'director' | 'vice_director' | 'admin' | 'teacher';
  staffId: string;
}

export type DocumentCategory =
  | 'leave_request' // លិខិតសុំច្បាប់
  | 'mission_letter' // លិខិតបេសកកម្ម
  | 'absence_record' // កំណត់ត្រាករណីអវត្តមាន
  | 'holiday_notice' // សេចក្តីជូនដំណឹងថ្ងៃបុណ្យ/ឈប់សម្រាក
  | 'official_letter' // លិខិតរដ្ឋបាលទូទៅ
  | 'other'; // ផ្សេងៗ

export interface SchoolDocument {
  id?: string;
  title: string;
  category: DocumentCategory;
  staffName?: string;
  date: string;
  referenceNumber?: string;
  content: string;
  status: 'pending' | 'approved' | 'resolved' | 'archived';
  fileAttachmentUrl?: string; // base64 or file URL
  attachmentName?: string;
  createdAt?: string;
  updatedAt?: string;
  createdBy?: string;
}

export interface HolidayNoticeRecord {
  id?: string;
  holidayName: string;
  startDate: string;
  endDate: string;
  reopenDate: string;
  targetAudience: string;
  generatedTitle: string;
  generatedNotice: string;
  summary?: string;
  status: 'draft' | 'published';
  createdAt: string;
  createdBy?: string;
}

export interface TelegramNotificationLog {
  id: string;
  timestamp: string;
  staffName: string;
  staffPosition?: string;
  periodLabel: string;
  timeStr: string;
  dateStr: string;
  status: 'sent' | 'simulated' | 'failed';
  messagePreview?: string;
  error?: string;
}

export interface TelegramSettings {
  autoNotify: boolean;
  notifyMorningIn: boolean;
  notifyMorningOut: boolean;
  notifyAfternoonIn: boolean;
  notifyAfternoonOut: boolean;
  includeGpsStatus: boolean;
  showSignatureConfirm: boolean;
}

export interface BrowserPushNotificationItem {
  id: string;
  timestamp: string;
  title: string;
  body: string;
  type: 'signature' | 'edit' | 'leave' | 'test' | 'system';
  staffName?: string;
  periodLabel?: string;
  read?: boolean;
}

export interface PushNotificationSettings {
  enabled: boolean;
  soundEnabled: boolean;
  notifyOnSignature: boolean;
  notifyOnDataEdit: boolean;
  notifyOnLeaveRequest: boolean;
}
