// Comprehensive Cambodian Khmer Calendar (ចន្ទគតិ & សុរិយគតិ), Holidays, and Working Day Calculations

export interface KhmerLunarInfo {
  dayNumber: number; // 1-15
  phase: 'កើត' | 'រោច';
  lunarMonth: string;
  animal: string;
  sak: string;
  buddhistYear: number;
  isBuddhistHolyDay: boolean;
  holyDayLabel?: string;
  formattedLunar: string;
}

export interface KhmerHoliday {
  name: string;
  shortName: string;
  isHoliday: boolean;
  type: 'national' | 'ceremony' | 'royal';
}

export const KH_NUMBERS = ['០', '១', '២', '៣', '៤', '៥', '៦', '៧', '៨', '៩'];

export function toKhmer(n: number | string): string {
  return String(n)
    .split('')
    .map((c) => (c >= '0' && c <= '9' ? KH_NUMBERS[parseInt(c, 10)] : c))
    .join('');
}

export const KH_MONTHS_SOLAR = [
  'មករា',
  'កុម្ភៈ',
  'មីនា',
  'មេសា',
  'ឧសភា',
  'មិថុនា',
  'កក្កដា',
  'សីហា',
  'កញ្ញា',
  'តុលា',
  'វិច្ឆិកា',
  'ធ្នូ',
];

export const KH_WEEKDAYS_LONG = [
  'ថ្ងៃអាទិត្យ',
  'ថ្ងៃចន្ទ',
  'ថ្ងៃអង្គារ',
  'ថ្ងៃពុធ',
  'ថ្ងៃព្រហស្បតិ៍',
  'ថ្ងៃសុក្រ',
  'ថ្ងៃសៅរ៍',
];

export const KH_WEEKDAYS_SHORT = ['អា', 'ច', 'អ', 'ព', 'ព្រ', 'សុ', 'ស'];

export const KH_MONTHS_LUNAR = [
  'មិគសិរ',
  'បុស្ស',
  'មាឃ',
  'ផល្គុន',
  'ចេត្រ',
  'ពិសាខ',
  'ជេស្ឋ',
  'អាសាឍ',
  'ស្រាពណ៍',
  'ភទ្របទ',
  'អស្សុជ',
  'កត្តិក',
];

export const KH_ANIMALS = [
  'ជូត',
  'ឆ្លូវ',
  'ខាល',
  'ថោះ',
  'រោង',
  'ម្សាញ់',
  'មមី',
  'មមែ',
  'វក',
  'រកា',
  'ច',
  'កុរ',
];

export const KH_SAK = [
  'សំរឹទ្ធិស័ក',
  'ឯកស័ក',
  'ទោស័ក',
  'ត្រីស័ក',
  'ចត្វាស័ក',
  'បញ្ចស័ក',
  'ឆស័ក',
  'សប្តស័ក',
  'អដ្ឋស័ក',
  'នព្វស័ក',
];

/**
 * Computes exact Khmer Lunar (ចន្ទគតិ) Information for any Gregorian Date.
 * Calibrated against Cambodian Royal Lunar almanac.
 */
export function getKhmerLunarInfo(dateInput: Date | string): KhmerLunarInfo {
  const d = typeof dateInput === 'string' ? new Date(dateInput + 'T00:00:00') : new Date(dateInput);

  // Calibration anchor: 2026-05-13 is Pisakh 9th day
  const base = new Date('2026-05-13T00:00:00');
  const diffDays = Math.round((d.getTime() - base.getTime()) / (1000 * 60 * 60 * 24));

  // Lunar day inside 30-day lunar cycle
  let ld = (9 + diffDays) % 30;
  if (ld <= 0) ld += 30;

  const phase: 'កើត' | 'រោច' = ld <= 15 ? 'កើត' : 'រោច';
  const dayNumber = ld <= 15 ? ld : ld - 15 || 15;

  // Approximate lunar month progression from solar month
  // Note: Lunar month shift usually happens mid-solar month
  const m = d.getMonth();
  const lm = KH_MONTHS_LUNAR[m] || 'មាឃ';

  // Chhankitek era and year calculation
  const afterKhmerNewYear = d.getMonth() > 3 || (d.getMonth() === 3 && d.getDate() >= 14);
  const cs = afterKhmerNewYear ? d.getFullYear() - 638 : d.getFullYear() - 639;
  const be = cs + 1182; // Buddhist Era (ព.ស)
  const animalName = KH_ANIMALS[(((cs % 12) + 12) % 12 + 10) % 12];
  const sakName = KH_SAK[((cs % 10) + 10) % 10];

  // Buddhist holy days (ថ្ងៃសីល): 8 waxing, 15 waxing, 8 waning, 14 or 15 waning
  let isBuddhistHolyDay = false;
  let holyDayLabel: string | undefined;

  if (phase === 'កើត' && dayNumber === 8) {
    isBuddhistHolyDay = true;
    holyDayLabel = 'ថ្ងៃសីល (៨កើត)';
  } else if (phase === 'កើត' && dayNumber === 15) {
    isBuddhistHolyDay = true;
    holyDayLabel = 'ថ្ងៃសីល ពេញបូណ៌មី (១៥កើត)';
  } else if (phase === 'រោច' && dayNumber === 8) {
    isBuddhistHolyDay = true;
    holyDayLabel = 'ថ្ងៃសីល (៨រោច)';
  } else if (phase === 'រោច' && (dayNumber === 14 || dayNumber === 15)) {
    isBuddhistHolyDay = true;
    holyDayLabel = 'ថ្ងៃសីល ដាច់ខែ';
  }

  const formattedLunar = `${KH_WEEKDAYS_LONG[d.getDay()]} ${toKhmer(dayNumber)}${phase} ខែ${lm} ឆ្នាំ${animalName} ${sakName} ព.ស ${toKhmer(be)}`;

  return {
    dayNumber,
    phase,
    lunarMonth: lm,
    animal: animalName,
    sak: sakName,
    buddhistYear: be,
    isBuddhistHolyDay,
    holyDayLabel,
    formattedLunar,
  };
}

/**
 * Official Public Holidays in Cambodia (ថ្ងៃឈប់សម្រាកបុណ្យជាតិផ្លូវការ)
 * Includes both fixed solar holidays and dynamic lunar holidays.
 */
const FIXED_HOLIDAYS: Record<string, KhmerHoliday> = {
  '01-01': { name: 'ទិវាចូលឆ្នាំសកល', shortName: 'ចូលឆ្នាំសកល', isHoliday: true, type: 'national' },
  '01-07': { name: 'ទិវាជ័យជម្នះលើរបបប្រល័យពូជសាសន៍', shortName: '៧ មករា', isHoliday: true, type: 'national' },
  '03-08': { name: 'ទិវានារីអន្តរជាតិ', shortName: 'ទិវានារី', isHoliday: true, type: 'national' },
  '04-13': { name: 'ពិធីបុណ្យចូលឆ្នាំថ្មី ប្រពៃណីជាតិ (ថ្ងៃទី១)', shortName: 'ចូលឆ្នាំថ្មី', isHoliday: true, type: 'ceremony' },
  '04-14': { name: 'ពិធីបុណ្យចូលឆ្នាំថ្មី ប្រពៃណីជាតិ (ថ្ងៃទី២)', shortName: 'ចូលឆ្នាំថ្មី', isHoliday: true, type: 'ceremony' },
  '04-15': { name: 'ពិធីបុណ្យចូលឆ្នាំថ្មី ប្រពៃណីជាតិ (ថ្ងៃទី៣)', shortName: 'ចូលឆ្នាំថ្មី', isHoliday: true, type: 'ceremony' },
  '04-16': { name: 'ពិធីបុណ្យចូលឆ្នាំថ្មី ប្រពៃណីជាតិ (ថ្ងៃទី៤)', shortName: 'ចូលឆ្នាំថ្មី', isHoliday: true, type: 'ceremony' },
  '05-01': { name: 'ទិវាពលកម្មអន្តរជាតិ', shortName: 'ទិវាពលកម្ម', isHoliday: true, type: 'national' },
  '05-14': { name: 'ព្រះរាជពិធីបុណ្យចម្រើនព្រះជន្ម ព្រះករុណា ព្រះបាទសម្តេច ព្រះបរមនាថ នរោត្តម សីហមុនី', shortName: 'ចម្រើនព្រះជន្ម ព្រះមហាក្សត្រ', isHoliday: true, type: 'royal' },
  '06-18': { name: 'ព្រះរាជពិធីបុណ្យចម្រើនព្រះជន្ម សម្តេចព្រះមហាក្សត្រី នរោត្តម មុនិនាថ សីហនុ', shortName: 'ចម្រើនព្រះជន្ម សម្តេចម៉ែ', isHoliday: true, type: 'royal' },
  '09-24': { name: 'ទិវាប្រកាសរដ្ឋធម្មនុញ្ញ', shortName: 'ទិវារដ្ឋធម្មនុញ្ញ', isHoliday: true, type: 'national' },
  '10-15': { name: 'ទិវាប្រារព្ធពិធីគោរពព្រះវិញ្ញាណក្ខន្ធ ព្រះបរមរតនកោដ្ឋ', shortName: 'គោរពព្រះវិញ្ញាណក្ខន្ធ', isHoliday: true, type: 'royal' },
  '10-29': { name: 'ព្រះរាជពិធីគ្រងព្រះបរមរាជសម្បត្តិ ព្រះករុណា ព្រះបាទសម្តេច ព្រះបរមនាថ នរោត្តម សីហមុនី', shortName: 'គ្រងរាជសម្បត្តិ', isHoliday: true, type: 'royal' },
  '11-09': { name: 'ពិធីបុណ្យឯករាជ្យជាតិ', shortName: 'បុណ្យឯករាជ្យជាតិ', isHoliday: true, type: 'national' },
};

/**
 * Dynamic lunar-based public holidays mapped by YYYY-MM-DD
 */
const DYNAMIC_HOLIDAYS: Record<string, KhmerHoliday> = {
  // 2025
  '2025-02-12': { name: 'ពិធីបុណ្យមាឃបូជា', shortName: 'មាឃបូជា', isHoliday: true, type: 'ceremony' },
  '2025-05-11': { name: 'ពិធីបុណ្យវិសាខបូជា', shortName: 'វិសាខបូជា', isHoliday: true, type: 'ceremony' },
  '2025-05-15': { name: 'ព្រះរាជពិធីច្រត់ព្រះនង្គ័ល', shortName: 'ច្រត់ព្រះនង្គ័ល', isHoliday: true, type: 'ceremony' },
  '2025-09-21': { name: 'ពិធីបុណ្យភ្ជុំបិណ្ឌ (ថ្ងៃទី១)', shortName: 'ភ្ជុំបិណ្ឌ', isHoliday: true, type: 'ceremony' },
  '2025-09-22': { name: 'ពិធីបុណ្យភ្ជុំបិណ្ឌ (ថ្ងៃទី២)', shortName: 'ភ្ជុំបិណ្ឌ', isHoliday: true, type: 'ceremony' },
  '2025-09-23': { name: 'ពិធីបុណ្យភ្ជុំបិណ្ឌ (ថ្ងៃភ្ជុំធំ)', shortName: 'ភ្ជុំធំ', isHoliday: true, type: 'ceremony' },
  '2025-11-04': { name: 'ព្រះរាជពិធីបុណ្យអុំទូក (ថ្ងៃទី១)', shortName: 'បុណ្យអុំទូក', isHoliday: true, type: 'ceremony' },
  '2025-11-05': { name: 'ព្រះរាជពិធីបុណ្យអុំទូក (ថ្ងៃទី២)', shortName: 'បុណ្យអុំទូក', isHoliday: true, type: 'ceremony' },
  '2025-11-06': { name: 'ព្រះរាជពិធីបុណ្យអុំទូក (ថ្ងៃទី៣)', shortName: 'បុណ្យអុំទូក', isHoliday: true, type: 'ceremony' },

  // 2026
  '2026-02-03': { name: 'ពិធីបុណ្យមាឃបូជា', shortName: 'មាឃបូជា', isHoliday: true, type: 'ceremony' },
  '2026-05-01': { name: 'ពិធីបុណ្យវិសាខបូជា', shortName: 'វិសាខបូជា', isHoliday: true, type: 'ceremony' },
  '2026-05-05': { name: 'ព្រះរាជពិធីច្រត់ព្រះនង្គ័ល', shortName: 'ច្រត់ព្រះនង្គ័ល', isHoliday: true, type: 'ceremony' },
  '2026-09-10': { name: 'ពិធីបុណ្យភ្ជុំបិណ្ឌ (ថ្ងៃទី១)', shortName: 'ភ្ជុំបិណ្ឌ', isHoliday: true, type: 'ceremony' },
  '2026-09-11': { name: 'ពិធីបុណ្យភ្ជុំបិណ្ឌ (ថ្ងៃទី២)', shortName: 'ភ្ជុំបិណ្ឌ', isHoliday: true, type: 'ceremony' },
  '2026-09-12': { name: 'ពិធីបុណ្យភ្ជុំបិណ្ឌ (ថ្ងៃភ្ជុំធំ)', shortName: 'ភ្ជុំធំ', isHoliday: true, type: 'ceremony' },
  '2026-10-10': { name: 'ពិធីបុណ្យភ្ជុំបិណ្ឌ (ថ្ងៃទី១)', shortName: 'ភ្ជុំបិណ្ឌ', isHoliday: true, type: 'ceremony' },
  '2026-10-11': { name: 'ពិធីបុណ្យភ្ជុំបិណ្ឌ (ថ្ងៃទី២)', shortName: 'ភ្ជុំបិណ្ឌ', isHoliday: true, type: 'ceremony' },
  '2026-10-12': { name: 'ពិធីបុណ្យភ្ជុំបិណ្ឌ (ថ្ងៃភ្ជុំធំ)', shortName: 'ភ្ជុំធំ', isHoliday: true, type: 'ceremony' },
  '2026-11-23': { name: 'ព្រះរាជពិធីបុណ្យអុំទូក (ថ្ងៃទី១)', shortName: 'បុណ្យអុំទូក', isHoliday: true, type: 'ceremony' },
  '2026-11-24': { name: 'ព្រះរាជពិធីបុណ្យអុំទូក (ថ្ងៃទី២)', shortName: 'បុណ្យអុំទូក', isHoliday: true, type: 'ceremony' },
  '2026-11-25': { name: 'ព្រះរាជពិធីបុណ្យអុំទូក (ថ្ងៃទី៣)', shortName: 'បុណ្យអុំទូក', isHoliday: true, type: 'ceremony' },

  // 2027
  '2027-02-21': { name: 'ពិធីបុណ្យមាឃបូជា', shortName: 'មាឃបូជា', isHoliday: true, type: 'ceremony' },
  '2027-05-20': { name: 'ពិធីបុណ្យវិសាខបូជា', shortName: 'វិសាខបូជា', isHoliday: true, type: 'ceremony' },
  '2027-05-24': { name: 'ព្រះរាជពិធីច្រត់ព្រះនង្គ័ល', shortName: 'ច្រត់ព្រះនង្គ័ល', isHoliday: true, type: 'ceremony' },
  '2027-09-29': { name: 'ពិធីបុណ្យភ្ជុំបិណ្ឌ (ថ្ងៃទី១)', shortName: 'ភ្ជុំបិណ្ឌ', isHoliday: true, type: 'ceremony' },
  '2027-09-30': { name: 'ពិធីបុណ្យភ្ជុំបិណ្ឌ (ថ្ងៃទី២)', shortName: 'ភ្ជុំបិណ្ឌ', isHoliday: true, type: 'ceremony' },
  '2027-10-01': { name: 'ពិធីបុណ្យភ្ជុំបិណ្ឌ (ថ្ងៃភ្ជុំធំ)', shortName: 'ភ្ជុំធំ', isHoliday: true, type: 'ceremony' },
  '2027-11-12': { name: 'ព្រះរាជពិធីបុណ្យអុំទូក (ថ្ងៃទី១)', shortName: 'បុណ្យអុំទូក', isHoliday: true, type: 'ceremony' },
  '2027-11-13': { name: 'ព្រះរាជពិធីបុណ្យអុំទូក (ថ្ងៃទី២)', shortName: 'បុណ្យអុំទូក', isHoliday: true, type: 'ceremony' },
  '2027-11-14': { name: 'ព្រះរាជពិធីបុណ្យអុំទូក (ថ្ងៃទី៣)', shortName: 'បុណ្យអុំទូក', isHoliday: true, type: 'ceremony' },
};

/**
 * Returns holiday information for a given date if it is an official public holiday.
 */
export function getKhmerHoliday(dateInput: Date | string): KhmerHoliday | null {
  const d = typeof dateInput === 'string' ? new Date(dateInput + 'T00:00:00') : new Date(dateInput);
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  const dateStr = `${yyyy}-${mm}-${dd}`;
  const monthDay = `${mm}-${dd}`;

  // Check dynamic holidays first
  if (DYNAMIC_HOLIDAYS[dateStr]) {
    return DYNAMIC_HOLIDAYS[dateStr];
  }

  // Check fixed annual solar holidays
  if (FIXED_HOLIDAYS[monthDay]) {
    return FIXED_HOLIDAYS[monthDay];
  }

  return null;
}

/**
 * Determines whether a given day is an official WORKING DAY (ថ្ងៃធ្វើការ)
 * In Cambodian schools and civil service:
 * - Sundays are rest days (non-working).
 * - Public holidays are rest days (non-working).
 */
export function isKhmerWorkingDay(dateInput: Date | string): boolean {
  const d = typeof dateInput === 'string' ? new Date(dateInput + 'T00:00:00') : new Date(dateInput);
  const dayOfWeek = d.getDay();

  // Sunday is weekend rest day
  if (dayOfWeek === 0) {
    return false;
  }

  // Check official public holidays
  if (getKhmerHoliday(d) !== null) {
    return false;
  }

  return true;
}

/**
 * Determines whether a given day is a Cambodian Primary School Working Day.
 * Standard Primary School Schedule:
 * - 4 weeks per month:
 *   - Weeks 1, 2, 3: 6 working days (Mon-Sat, Sunday rest day)
 *   - Week 4: 5 working days (Thursday of Week 4, days 22-28, is monthly technical meeting day - non-work)
 * - Public holidays are rest days.
 */
export function isSchoolWorkingDay(dateInput: Date | string): {
  isWorking: boolean;
  reason?: string;
  isSunday?: boolean;
  isHoliday?: boolean;
  isThursdayMeeting?: boolean;
} {
  const d = typeof dateInput === 'string' ? new Date(dateInput + 'T00:00:00') : new Date(dateInput);
  const dayOfWeek = d.getDay();
  const dayOfMonth = d.getDate();

  // 1. Sunday rest day
  if (dayOfWeek === 0) {
    return { isWorking: false, reason: 'ថ្ងៃអាទិត្យ (ឈប់សម្រាក)', isSunday: true };
  }

  // 2. Thursday in Week 4 (day 22 to 28): Monthly Technical Meeting
  if (dayOfWeek === 4 && dayOfMonth >= 22 && dayOfMonth <= 28) {
    return {
      isWorking: false,
      reason: 'ថ្ងៃព្រហស្បតិ៍សប្ដាហ៍ទី៤ (ប្រជុំបច្ចេកទេសប្រចាំខែ)',
      isThursdayMeeting: true,
    };
  }

  // 3. Official Public Holiday
  const holiday = getKhmerHoliday(d);
  if (holiday !== null) {
    return {
      isWorking: false,
      reason: `បុណ្យជាតិ៖ ${holiday.name}`,
      isHoliday: true,
    };
  }

  return { isWorking: true };
}

/**
 * Formats a Date in full Khmer Solar format
 */
export function formatKhmerSolarDateFull(d: Date | string): string {
  const date = typeof d === 'string' ? new Date(d + 'T00:00:00') : d;
  return `ថ្ងៃទី${toKhmer(date.getDate())} ខែ${KH_MONTHS_SOLAR[date.getMonth()]} ឆ្នាំ${toKhmer(date.getFullYear())}`;
}
